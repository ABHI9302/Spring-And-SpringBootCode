package in.ashokit.Sb_function01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbFunction01Application {

	public static void main(String[] args) {
		SpringApplication.run(SbFunction01Application.class, args);
	}

}
