package in.ashokit.Sb_function01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbFunction01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
