package in.ashokit.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDelect01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
